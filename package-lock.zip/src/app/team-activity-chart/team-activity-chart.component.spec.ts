import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamActivityChartComponent } from './team-activity-chart.component';

describe('TeamActivityChartComponent', () => {
  let component: TeamActivityChartComponent;
  let fixture: ComponentFixture<TeamActivityChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TeamActivityChartComponent]
    });
    fixture = TestBed.createComponent(TeamActivityChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
