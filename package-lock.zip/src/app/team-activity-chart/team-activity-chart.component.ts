import { Component } from '@angular/core';

@Component({
  selector: 'app-team-activity-chart',
  templateUrl: './team-activity-chart.component.html',
  styleUrls: ['./team-activity-chart.component.scss']
})
export class TeamActivityChartComponent {

}
