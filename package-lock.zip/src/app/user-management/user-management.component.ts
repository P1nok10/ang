import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from '../service/user.service';
import { User } from '../model/user.model';
import { UserDto } from '../model/user-dto.model';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss']
})
export class UserManagementComponent implements OnInit {
  displayedColumns: string[] = ['id', 'username', 'firstName', 'lastName', 'vpnLogin', 'vpnDeviceNumber', 'actions'];
  dataSource!: MatTableDataSource<User>;
  selectedUser: User | null = null;
  newUser: UserDto = new UserDto();
  createUserFormVisible: boolean = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    this.fetchUsers();
  }

  fetchUsers(): void {
    this.userService.getUsers().subscribe({
      next: users => {
        this.dataSource = new MatTableDataSource<User>(users);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error: (error) => {
        console.error(error);
      }
    });
  }

  createUser(user: UserDto): void {
    this.userService.createUser(user).subscribe(
      (newUser: User) => {
        // Refresh the table data
        this.fetchUsers();
        // Hide the create user form
        this.toggleCreateUserForm();
      },
      (error) => {
        console.error(error);
      }
    );
  }

  updateUser(user: User): void {
    this.userService.updateUser(user.id, user).subscribe(
      (updatedUser: User) => {
        // Refresh the table data
        this.fetchUsers();
        // Deselect the selected user
        this.selectedUser = null;
      },
      (error) => {
        console.error(error);
      }
    );
  }

  deleteUser(user: User): void {
    this.userService.deleteUser(user.id).subscribe(
      () => {
        // Remove the user from the dataSource
        const index = this.dataSource.data.findIndex(u => u.id === user.id);
        if (index !== -1) {
          this.dataSource.data.splice(index, 1);
          this.dataSource._updateChangeSubscription(); // Notify the table that the data has changed
        }
      },
      (error) => {
        console.error(error);
      }
    );
  }
  

  toggleCreateUserForm(): void {
    this.createUserFormVisible = !this.createUserFormVisible;
  }

  selectUser(user: User): void {
    this.selectedUser = user;
  }
}
