import { Injectable } from '@angular/core';
import { RangeValueAccessor } from '@angular/forms';

export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
}

const MENUITEMS = [
  { state: 'dashboard', name: 'Dashboard', type: 'link', icon: 'dashboard' },
  { state: 'user-management', type: 'link', name: 'User Management', icon: 'person'},
  { state:  'flux-access-request', type: 'link', name:'Ouverture de flux', icon: 'lock_open'},
  { state: 'create-ticket', type: 'link', name: 'Create Ticket', icon: 'add_circle' },
  { state: 'my-tickets', type: 'link', name: 'My Tickets', icon: 'list_alt' },
  { state: 'all-tickets', type: 'link', name: 'All Tickets', icon: 'assignment' },
  { state: 'reports', type: 'link', name: 'Reports', icon: 'bar_chart' },
  { state: 'settings', type: 'link', name: 'Settings', icon: 'settings' },
  { state: 'logout', type: 'link', name: 'Logout', icon: 'exit_to_app' },
];

@Injectable()
export class MenuItems {
  getMenuitem(): Menu[] {
    return MENUITEMS;
  }
}
