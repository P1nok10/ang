
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, provideRouter } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { AppRoutes } from './app.routing';
import { AppComponent } from './app.component';
import { HighchartsChartModule } from 'highcharts-angular';

import { FullComponent } from './layouts/full/full.component';
import { AppHeaderComponent } from './layouts/full/header/header.component';
import { AppSidebarComponent } from './layouts/full/sidebar/sidebar.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DemoMaterialModule } from './demo-material-module';

import { SharedModule } from './shared/shared.module';
import { SpinnerComponent } from './shared/spinner.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth.guard';
import { CreateTicketComponent } from './create-ticket/create-ticket.component';
import { AllTicketComponent } from './all-ticket/all-ticket.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { TeamActivityChartComponent } from './team-activity-chart/team-activity-chart.component';
import { FluxAccessRequestComponent } from './flux-access-request/flux-access-request.component';
import { FluxAccessService } from './service/flux-access.service';



@NgModule({
  declarations: [
    AppComponent,
    FullComponent,
    AppHeaderComponent,
    SpinnerComponent,
    LoginComponent,
    CreateTicketComponent,
    AllTicketComponent,
    UserManagementComponent,
    TeamActivityChartComponent,
    FluxAccessRequestComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    DashboardComponent,
    DemoMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HighchartsChartModule,
    HttpClientModule,
    SharedModule,
    RouterModule.forRoot(AppRoutes),
    AppSidebarComponent,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatInputModule,
    MatFormFieldModule,
  ],
  providers: [
    FluxAccessService,
    {
      provide: LocationStrategy,
      useClass: PathLocationStrategy
    },
/*    {
      provide: authGuard,
      useClass: authGuard // Change this line to useClass: AuthGuard
    }  */
    /* provideRouter([
      {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard] 
      },
    ]), */
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
