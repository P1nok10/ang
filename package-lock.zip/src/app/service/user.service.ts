import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../model/user.model';
import { AuthToken } from '../model/auth-token.model';
import { LoginUser } from '../model/login-user.model';
import { UserDto } from '../model/user-dto.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = 'http://localhost:8080/users';
  private headers = new HttpHeaders().set('Authorization', 'Bearer ' + localStorage.getItem('jwt'));

  constructor(private http: HttpClient) { }

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`http://localhost:8080/users/find/all`, { headers: this.headers });
    console.log();

  }

  getUser(id: number): Observable<User> {
    return this.http.get<User>(`${this.baseUrl}/${id}`, { headers: this.headers });
  }

  createUser(user: UserDto): Observable<User> {
    return this.http.post<User>(`${this.baseUrl}/create/employee`, user, { headers: this.headers });
  }

  updateUser(id: number, user: User): Observable<User> {
    return this.http.put<User>(`${this.baseUrl}/update/${id}`, user, { headers: this.headers });
  }

  deleteUser(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/delete/${id}`, { headers: this.headers });
  }

/*   authenticateUser(username: string, password: string): Observable<AuthToken> {
    const loginUser = new LoginUser(username, password);
    return this.http.post<AuthToken>(`${this.baseUrl}/authenticate`, loginUser);
  } */

  findUserByUsername(username: string): Observable<User> {
    return this.http.get<User>(`${this.baseUrl}/find/by/username?username=${username}`, { headers: this.headers });
  }
}