import { TestBed } from '@angular/core/testing';

import { FluxAccessService } from './flux-access.service';

describe('FluxAccessService', () => {
  let service: FluxAccessService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FluxAccessService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
