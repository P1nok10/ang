// src/app/services/flux-access.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  RequestFlux,
  RequestAccessDetail,
  Port,
  RequestAccessPort
} from '../model/flux-request.model';

@Injectable({
  providedIn: 'root'
})
export class FluxAccessService {
  private apiUrl = 'http://localhost:8080/api'; // Replace with your backend API URL

  constructor(private http: HttpClient) {}

  getRequestFluxes(): Observable<RequestFlux[]> {
    return this.http.get<RequestFlux[]>(`${this.apiUrl}/requestFlux`);
  }

  getRequestAccessDetails(): Observable<RequestAccessDetail[]> {
    return this.http.get<RequestAccessDetail[]>(`${this.apiUrl}/requestAccessDetail`);
  }

  createRequestFlux(requestFlux: RequestFlux): Observable<RequestFlux> {
    return this.http.post<RequestFlux>(`${this.apiUrl}/requestFlux`, requestFlux);
  }

  createRequestAccessDetail(requestAccessDetail: RequestAccessDetail): Observable<RequestAccessDetail> {
    return this.http.post<RequestAccessDetail>(`${this.apiUrl}/requestAccessDetail`, requestAccessDetail);
  }

  getPorts(): Observable<Port[]> {
    return this.http.get<Port[]>(`${this.apiUrl}/ports`);
  }

  createPort(port: Port): Observable<Port> {
    return this.http.post<Port>(`${this.apiUrl}/ports`, port);
  }

  getRequestAccessPorts(): Observable<RequestAccessPort[]> {
    return this.http.get<RequestAccessPort[]>(`${this.apiUrl}/requestAccessPorts`);
  }

  createRequestAccessPort(requestAccessPort: RequestAccessPort): Observable<RequestAccessPort> {
    return this.http.post<RequestAccessPort>(`${this.apiUrl}/requestAccessPorts`, requestAccessPort);
  }
}
