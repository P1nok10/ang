import { Routes } from '@angular/router';

import { FullComponent } from './layouts/full/full.component';

import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { tick } from '@angular/core/testing';
import { CreateTicketComponent } from './create-ticket/create-ticket.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { AllTicketComponent } from './all-ticket/all-ticket.component';
import { FluxAccessRequestComponent } from './flux-access-request/flux-access-request.component';

 export const AppRoutes: Routes = [
  { path: "login", component: LoginComponent },
/*   { path: "forgot-password", component: ForgotPasswordComponent },
  { path: "reset-password", component: ResetPasswordComponent }, */
  {
    path: '',
    component: FullComponent,
    children: [
      { path: "flux-access-request", component: FluxAccessRequestComponent},
      { path: "create-ticket", component: CreateTicketComponent },
      { path: "user-management", component: UserManagementComponent},
      { path: "all-tickets", component: AllTicketComponent},
      {
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full'
      },
      {
        path: '',
        loadChildren:
          () => import('./material-component/material.module').then(m => m.MaterialComponentsModule),
      },
      {
        path: 'dashboard',
        loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule),
        canActivate: [AuthGuard]
      }
    ]
  }
];
