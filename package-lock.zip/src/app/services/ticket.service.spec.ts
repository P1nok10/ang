import { TestBed } from '@angular/core/testing';

import { ticketservice } from './ticket.service';

describe('ticketservice', () => {
  let service: ticketservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ticketservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
