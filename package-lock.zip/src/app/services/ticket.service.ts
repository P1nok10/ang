import { Injectable } from '@angular/core';
import {HttpClient, HttpResponse} from "@angular/common/http";
import {Observable} from "rxjs";
import {ticket} from "../model/ticket.model";

@Injectable({
  providedIn: 'root'
})
export class ticketservice {

  constructor(private http: HttpClient) { }

  public getTickets(page : number=1, size:number=4):Observable<ticket[]>{
  // ?_page=${page}&_limit=${size}
    return this.http.get <ticket[]>(`http://localhost:8080/api/tickets`);
  }
/*   public checkticket(ticket:ticket):Observable<ticket>{
    return this.http.patch<ticket>(`http://localhost:8080/api/tickets/${ticket.id}`,
      {checked:!ticket.checked});
  } */
  public deleteticket(ticket:ticket){
    return this.http.delete<any>(`http://localhost:8080/api/tickets/${ticket.id}`);
  }

  saveticket(ticket: ticket):Observable<ticket> {
    return this.http.post<ticket>(`http://localhost:8080/api/tickets`,ticket);
  }

  public searchtickets(keyword:string):Observable<Array<ticket>>{
    return this.http.get<Array<ticket>>(`http://localhost:8080/api/tickets?name_like=${keyword}`);
  }
}
