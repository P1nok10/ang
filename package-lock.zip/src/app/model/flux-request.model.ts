// src/app/models/flux-access.model.ts

import { User } from "./user.model";
  
  export interface Ip {
    id: number;
    ip: string;
  }
  
  export interface Port {
    id: number;
    port: string;
    ip: Ip;
  }
  
  export interface RequestFluxDetail {
userName: any;
    id: number;
    ipSource: string;
    identificationSource: string;
    ip: Ip;
    ports: Port[];
    requestFlux: RequestFlux;
  }
  
  export interface RequestFlux {
utilisateur: any;
loginVPN: any;
deviceSerialNumber: any;
    id: number;
    name: string;
    requestFluxDetail: RequestFluxDetail;
  }
  
  export interface RequestAccessPort {
    id: number;
    portNumber: number;
    portDescription: string;
    requestAccess: RequestAccess;
  }
  
  export interface RequestAccess {
    id: number;
    user: User;
    ports: RequestAccessPort[];
  }
  
  export interface RequestAccessDetail {
    id: number;
    requestAccess: RequestAccess;
    env: string;
    module: string;
  }
  