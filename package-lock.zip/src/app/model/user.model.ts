export interface User {
  id: number;
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  vpnLogin: string;
  vpnDeviceNumber: string;
  role: Role;
}

export interface Role {
  id: number;
  name: string;
  description: string;
}