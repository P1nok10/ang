export interface ticket {
  id?: number;
  title?: string;
  description?: string;
  type?: string;
  statut?: string;
  action?: string;
  chDev?: string;
  responsableId?: string;
  chifrage?: string;
  devTig?: Date;
  livraisonTig?: Date;
  dateReponse?: Date;
  ast?: string;
  commentaire?: string;
}