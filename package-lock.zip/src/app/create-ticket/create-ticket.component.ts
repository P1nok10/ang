import { Component } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {ticketservice} from "../services/ticket.service";
import {ticket} from "../model/ticket.model";
import { OnInit} from '@angular/core';


@Component({
  selector: 'app-create-ticket',
  templateUrl: './create-ticket.component.html',
  styleUrls: ['./create-ticket.component.scss']
})
export class CreateTicketComponent implements OnInit{
  public ticketForm!:FormGroup;

  constructor(private fb: FormBuilder, private ticketservice:ticketservice) {
  }
  ngOnInit() {
    this.ticketForm=this.fb.group({
      name : this.fb.control('', [Validators.required]),
      description : this.fb.control('',),
      checked : this.fb.control(true),
    });
  }

  saveticket() {
    let ticket:ticket=this.ticketForm.value;
    this.ticketservice.saveticket(ticket).subscribe({
      next : data => {
        alert(JSON.stringify(data));
      }, error :err => {
        console.log(err);
      }
    });
  }
}
