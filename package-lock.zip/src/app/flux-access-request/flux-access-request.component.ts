// src/app/components/flux-access-request/flux-access-request.component.ts
import { Component } from '@angular/core';
import { FluxAccessService } from '../service/flux-access.service';
import { User } from '../model/user.model';
import {
  RequestFlux,
  RequestFluxDetail,
  Ip,
  Port,
  RequestAccessDetail,
  RequestAccess,
  RequestAccessPort
} from '../model/flux-request.model';

@Component({
  selector: 'app-flux-access-request',
  templateUrl: './flux-access-request.component.html',
  styleUrls: ['./flux-access-request.component.css']
})
export class FluxAccessRequestComponent {
  
  requestFlux: RequestFlux = {
    id: 0,
    name: '',
    requestFluxDetail: {
      id: 0,
      ipSource: '',
      identificationSource: '',
      ip: {
        id: 0,
        ip: ''
      },
      ports: [],
      requestFlux: {} as RequestFlux,
      userName: undefined
    },
    utilisateur: undefined,
    loginVPN: undefined,
    deviceSerialNumber: undefined
  };

  requestAccessDetail: RequestAccessDetail = {
    id: 0,
    requestAccess: {
      id: 0,
      user: {
        id: 0,
        username: '',
        password: '',
        firstName: '',
        lastName: '',
        vpnLogin: '',
        vpnDeviceNumber: '',
        role: {
          id: 0,
          name: '',
          description: ''
        } // Assign a valid value to the role property
      },
      ports: []
    },
    env: '',
    module: ''
  };

  newPort: Port = {
    id: 0,
    port: '',
    ip: {
      id: 0,
      ip: ''
    }
  };

  newAccessPort: RequestAccessPort = {
    id: 0,
    requestAccess: {
      id: 0,
      user: {
        id: 0,
        username: '',
        password: '',
        firstName: '',
        lastName: '',
        vpnLogin: '',
        vpnDeviceNumber: '',
        role: {
          id: 0,
          name: '',
          description: ''
        } // Assign a valid value to the role property
      },
      ports: []
    },
    portNumber: 0,
    portDescription: ''
  };
// src/app/components/flux-access-request/flux-access-request.component.ts
// Add this to the existing class definition
displayedColumns: string[] = ['ipSource', 'identificationSource', 'ip', 'port', 'name', 'env', 'module', 'portNumber', 'portDescription'];


constructor(private fluxAccessService: FluxAccessService) {}

addPort(): void {
  this.requestFlux.requestFluxDetail.ports.push({ ...this.newPort });
  this.newPort.port = '';
}

addAccessPort(): void {
  this.requestAccessDetail.requestAccess.ports.push({ ...this.newAccessPort });
  this.newAccessPort.portNumber = 0;
  this.newAccessPort.portDescription = '';
}

onSubmit(): void {
  // Creating and saving RequestFlux
  this.fluxAccessService.createRequestFlux(this.requestFlux).subscribe(response => {
    console.log('Request Flux created:', response);
  });

  // Creating and saving RequestAccessDetail
  this.fluxAccessService.createRequestAccessDetail(this.requestAccessDetail).subscribe(response => {
    console.log('Request Access Detail created:', response);
  });
}
}
