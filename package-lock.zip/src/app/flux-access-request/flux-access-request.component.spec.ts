import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FluxAccessRequestComponent } from './flux-access-request.component';

describe('FluxAccessRequestComponent', () => {
  let component: FluxAccessRequestComponent;
  let fixture: ComponentFixture<FluxAccessRequestComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FluxAccessRequestComponent]
    });
    fixture = TestBed.createComponent(FluxAccessRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
