import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import * as XLSX from 'xlsx';

interface Ticket {
  title: string;
  description: string;
  type: string;
  action: string;
  responsableId: string;
  chDev: string;
  chifrage: string;
  devTig: string;
  livraisonTig: string;
  dateReponse: string;
  ast: string;
  commentaire: string;
}

@Component({
  selector: 'app-all-ticket',
  templateUrl: './all-ticket.component.html',
  styleUrls: ['./all-ticket.component.scss']
})
export class AllTicketComponent implements OnInit, AfterViewInit {
  dataSource: MatTableDataSource<Ticket> = new MatTableDataSource<Ticket>();
  displayedColumns: string[] = ['title', 'description', 'type', 'action', 'responsableId', 'chDev', 'chifrage', 'devTig', 'livraisonTig', 'dateReponse', 'ast', 'commentaire'];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor() {}

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  readFile(event: any): void {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const json: Ticket[] = XLSX.utils.sheet_to_json<Ticket>(sheet, { header: 1 }).map((row: any) => {
        return {
          title: row[0],
          description: row[1],
          type: row[2],
          action: row[3],
          responsableId: row[4],
          chDev: row[5],
          chifrage: row[6],
          devTig: row[7],
          livraisonTig: row[8],
          dateReponse: row[9],
          ast: row[10],
          commentaire: row[11]
        };
      });
      this.initializeDataSource(json);
    };
    reader.readAsArrayBuffer(file);
  }

  initializeDataSource(data: Ticket[]): void {
    this.dataSource.data = data;
  }
}
